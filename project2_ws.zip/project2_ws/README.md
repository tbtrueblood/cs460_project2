# Project 2: Outdoor Simulation

## Description

This is a ROS 2 package that contains an outdoor environment, specifically the area
between Paul W Bryant Drive and University Bulleavard going North/South, and
between Queen City Avenue and Red Drew Avenue going West/East in Tuscaloosa, Alabama

## Requirements to run

- ROS 2 Humble
- Webots and the 'webots_ros2_driver' package

## Installation

1. Clone this repository into your ROS2 workspace:

	cd ~/project2_ws/src
	git clone: https://github.com/tbtrueblood/project2.git
