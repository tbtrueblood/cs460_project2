from launch import LaunchDescription
from launch_ros.actions import Node
import os

def generate_launch_description():
    world_path = os.path.join(
        os.getenv('HOME'),
        'project2/src/project2/models/worlds/prj2.wbt"
    )
    
    return LaunchDescription([
        Node(
            package='webots_ros2_driver',
            executable='webots_node',
            name='webots',
            output='screen',
            parameters=[{'world': world_path}],
        ),
    ])
